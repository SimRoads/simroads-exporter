﻿namespace TsMap
{
    public class Settings
    {
        public string LastGamePath { get; set; }
        public string LastModPath { get; set; }
        public string LastTileMapPath { get; set; }
    }
}
