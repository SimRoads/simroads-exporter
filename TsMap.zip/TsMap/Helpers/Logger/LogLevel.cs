﻿namespace TsMap.Helpers.Logger
{
    internal enum LogLevel
    {
        Debug,
        Info,
        Warning,
        Error
    };
}
